The following Tables contain four variables for each month and for each even hour. 
1. Variable name "cam" represents the amount of cloud, 0 indicating clear sky, 10 overcast. 
2. variable name "cdr" represents the direction (from) of the movement of the clouds (true).
3. variable name "cfm" represents the form of cloud.
4. variable name "pri" represents precipitation in the form of Rain, Snow, Hail, Fog and Haze. 
The suffix symbol "-" indicates slight, "+" indicates strong or heavy. 