The direction of the wind was observed at the winter quarter, reckoned from the true meridian. The following Tables give the observed directions of the wind and the velocity, in metres per second, for each even hour and for the different months. 0 indicates Calm. 
The velocity of the wind was measured with Mohns hand-anemometer, friction-coefficient one meter per second. 
The variable name "wdr" represents wind direction.
The variable name "wve" represents wind velocity. 