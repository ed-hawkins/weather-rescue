Many errors in wind direction and force and in rain in masks So1_A2, So1_B2, So1_C2, even though data have been digitised at least 3 times!
Wind direction and speed have often been separated into different columns by users!
In rain amounts, dots close to the numbers in the images have sometimes been interpreted as decimal separators (also in So2 and So5)!

For masks So2, the images are often not aligned with the column titles and again the values for wind and clouds have often been put into the wrong columns.
